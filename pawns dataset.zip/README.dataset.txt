# board > 2024-07-26 8:07am
https://universe.roboflow.com/chessboard-recognition/board-wfrqi

Provided by a Roboflow user
License: CC BY 4.0

